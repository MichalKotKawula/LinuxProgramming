./client1 &
sleep 0.7
./client2 &
sleep 0.7
./client3 &
